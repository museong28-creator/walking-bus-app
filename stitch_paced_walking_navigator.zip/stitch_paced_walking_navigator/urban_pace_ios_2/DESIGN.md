---
name: Urban Pace iOS
colors:
  surface: '#051424'
  surface-dim: '#051424'
  surface-bright: '#2c3a4c'
  surface-container-lowest: '#010f1f'
  surface-container-low: '#0d1c2d'
  surface-container: '#122131'
  surface-container-high: '#1c2b3c'
  surface-container-highest: '#273647'
  on-surface: '#d4e4fa'
  on-surface-variant: '#bbcabf'
  inverse-surface: '#d4e4fa'
  inverse-on-surface: '#233143'
  outline: '#86948a'
  outline-variant: '#3c4a42'
  surface-tint: '#4edea3'
  primary: '#4edea3'
  on-primary: '#003824'
  primary-container: '#10b981'
  on-primary-container: '#00422b'
  inverse-primary: '#006c49'
  secondary: '#7bd0ff'
  on-secondary: '#00354a'
  secondary-container: '#00a6e0'
  on-secondary-container: '#00374d'
  tertiary: '#f9bd22'
  on-tertiary: '#402d00'
  tertiary-container: '#ce9a00'
  on-tertiary-container: '#4a3500'
  error: '#ffb4ab'
  on-error: '#690005'
  error-container: '#93000a'
  on-error-container: '#ffdad6'
  primary-fixed: '#6ffbbe'
  primary-fixed-dim: '#4edea3'
  on-primary-fixed: '#002113'
  on-primary-fixed-variant: '#005236'
  secondary-fixed: '#c4e7ff'
  secondary-fixed-dim: '#7bd0ff'
  on-secondary-fixed: '#001e2c'
  on-secondary-fixed-variant: '#004c69'
  tertiary-fixed: '#ffdf9f'
  tertiary-fixed-dim: '#f9bd22'
  on-tertiary-fixed: '#261a00'
  on-tertiary-fixed-variant: '#5c4300'
  background: '#051424'
  on-background: '#d4e4fa'
  surface-variant: '#273647'
typography:
  display-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 40px
    fontWeight: '700'
    lineHeight: 48px
    letterSpacing: -0.02em
  display-lg-mobile:
    fontFamily: Plus Jakarta Sans
    fontSize: 32px
    fontWeight: '700'
    lineHeight: 40px
    letterSpacing: -0.02em
  headline-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 28px
    fontWeight: '600'
    lineHeight: 36px
    letterSpacing: -0.015em
  headline-sm:
    fontFamily: Plus Jakarta Sans
    fontSize: 20px
    fontWeight: '600'
    lineHeight: 28px
    letterSpacing: -0.01em
  body-lg:
    fontFamily: Inter
    fontSize: 17px
    fontWeight: '400'
    lineHeight: 24px
    letterSpacing: -0.011em
  body-md:
    fontFamily: Inter
    fontSize: 15px
    fontWeight: '400'
    lineHeight: 22px
    letterSpacing: -0.009em
  label-lg:
    fontFamily: Inter
    fontSize: 13px
    fontWeight: '600'
    lineHeight: 18px
    letterSpacing: 0.02em
  label-sm:
    fontFamily: Inter
    fontSize: 11px
    fontWeight: '500'
    lineHeight: 14px
    letterSpacing: 0.04em
  metric-numeral:
    fontFamily: Plus Jakarta Sans
    fontSize: 36px
    fontWeight: '800'
    lineHeight: 40px
    letterSpacing: -0.03em
rounded:
  sm: 0.5rem
  DEFAULT: 1rem
  md: 1.5rem
  lg: 2rem
  xl: 3rem
  full: 9999px
spacing:
  gutter: 1rem
  gutter-sm: 0.75rem
  margin: 1rem
  margin-tablet: 1.5rem
  space-xs: 0.25rem
  space-sm: 0.5rem
  space-md: 1rem
  space-lg: 1.5rem
  space-xl: 2rem
---

## Brand & Style

This design system is engineered specifically for active night-time urban exploration, micro-navigation, and twilight fitness metrics. The visual personality balances technical precision with organic vitality, offering high legibility and minimal glare in low-light environments. 

The aesthetic synthesizes modern iOS-centric Glassmorphism with precision athletic performance cues:
- **Atmospheric Contrast**: Grounded in pure OLED black and deep slate layers that conserve battery and reduce peripheral eye fatigue.
- **Luminescent Telemetry**: High-vibrancy neon accents simulate backlit instrument clusters, guiding glances without disrupting night-adjusted vision.
- **Frosted Tactility**: Translucent blurred containers, refined hairline strokes, and continuous curvature (iOS squircle geometry) provide native platform familiarity and tactile reassurance on the move.

## Colors

The color architecture is built specifically for OLED displays and nocturnal usage, ensuring strict adherence to WCAG AAA contrast ratios for vital navigation telemetry against deep backdrops.

- **Primary (`#10B981`)**: Neon Emerald. Represents forward movement, pace confirmation, GPS lock, active tracking states, and positive delta values.
- **Secondary (`#38BDF8`)**: Luminous Cyan. Dedicated to secondary metrics, active route waypoints, elevation profiles, and informational telemetry.
- **Tertiary (`#FBBF24`)**: Signal Amber. Highlights cautionary alerts, route hazards, pause states, and pending milestones.
- **Destructive/Alert (`#F87171`)**: Soft Crimson. Applied strictly to critical deviations, off-route warnings, battery alerts, and termination actions.
- **Surfaces**:
  - `Canvas / Base`: `#0A0F14` (OLED power-saving base)
  - `Surface Tier 1`: `#121820` (Underlay and structural view modules)
  - `Surface Tier 2`: `#1A222D` (Interactive cards and bottom sheets)
  - `Surface Elevated`: `rgba(30, 41, 59, 0.72)` (Translucent frosted glass elements)
- **Text & Borders**:
  - `Text Primary`: `#F8FAFC` (100% legibility)
  - `Text Secondary`: `#94A3B8` (Pacing units, labels, inactive tabs)
  - `Hairline Border`: `rgba(255, 255, 255, 0.08)`

## Typography

The typographic hierarchy is designed for instant legibility at arm's length while walking or jogging under varying streetlamp conditions.

- **Plus Jakarta Sans** provides energetic geometry and wide aperture bowls for headings, navigation prompts, and critical numerical readouts (`metric-numeral`).
- **Inter** handles high-density micro-copy, lists, labels, and instructional prompts, maintaining clear glyph disambiguation even at 11px.
- **Tabular Figures**: Always enable `font-variant-numeric: tabular-nums` for dynamic metrics (pace, split timers, heart rate, distance) to avoid visual jitter during continuous real-time updates.

## Layout & Spacing

The layout model is optimized around handheld iOS ergonomics and safe-area boundaries:

- **Thumb-Zone Prioritization**: Primary interactions, track toggles, and turnaround buttons are positioned in the bottom 40% of the display. Map telemetries and environmental conditions reside in the upper visual register.
- **Screen Margin & Grid**: Standard edge margins are fixed at `1rem` (16px) on mobile viewports, expanding to `1.5rem` on larger tablet canvases. A 4-column fluid layout on phone displays transitions into an 8-column layout on iPad split-views.
- **Vertical Rhythm**: Layout gaps adhere to an 8pt base grid (`0.5rem`, `1rem`, `1.5rem`, `2rem`), utilizing `0.25rem` micro-steps strictly for unit tags adjacent to large metrics.

## Elevation & Depth

Visual depth is achieved through translucent glassmorphic layering, subtle rim lighting, and luminous glows rather than dark drop-shadows (which disappear into deep slate backgrounds).

- **Surface Backdrop**: Interactive panels utilize `rgba(30, 41, 59, 0.72)` combined with `backdrop-filter: blur(20px) saturate(180%)`.
- **Specular Hairline**: Cards and floating panels feature an inner perimeter stroke: `1px solid rgba(255, 255, 255, 0.08)`. This creates razor-sharp edge separation against black night maps.
- **Neon Luminance (Floating Actions)**: Primary interactive elements (such as "Start Walk" or "Turn-by-Turn Waypoint") utilize an emerald ambient glow: `box-shadow: 0 0 24px rgba(16, 185, 129, 0.35)`.
- **Z-Index Layering**:
  - `Level 0`: Fullscreen vector night map canvas (`#0A0F14`).
  - `Level 1`: Inset route stat ribbons and pinned background modules (`#121820`).
  - `Level 2`: Floating navigation cards, fitness detail trays, and bottom drawers (`#1A222D` with translucent blur).
  - `Level 3`: Toast notifications, off-route warnings, and modal overlay sheets.

## Shapes

The design system incorporates an iOS-native rounded pill shape language (Level 3), reinforcing fluid ergonomics and comfortable thumb target areas.

- **Buttons & Control Pills**: Full circular curvature (`border-radius: 9999px`) for CTA triggers, route toggles, pace chips, and interactive switches.
- **Metric Cards & Floating Modals**: Apply `rounded-xl` (`2rem` / 32px) or `rounded-lg` (`1.5rem` / 24px) continuous Apple squircles to soften the visual framing of dense tactical data.
- **Thumb Targets**: Touch targets must maintain a minimum bounding height of 48px to accommodate one-handed operation while moving.

## Components

### Buttons
- **Primary Action (Pill)**: Filled with Neon Emerald (`#10B981`), labeled with bold slate text (`#0A0F14`), styled with `rounded-full`, accompanied by an emerald proximity glow. On active press: scale down to `0.97` with brightness `1.1`.
- **Secondary Ghost Pill**: Frosted slate container (`rgba(255, 255, 255, 0.06)`), pure white label (`#F8FAFC`), hairline border (`rgba(255, 255, 255, 0.08)`).
- **Icon Buttons (Quick Turn / Center GPS)**: 48x48px circle, blurred backdrop, housing high-contrast SVG icons tinted in `#38BDF8` or `#F8FAFC`.

### Chips & Stat Badges
- Encapsulated pills featuring `0.25rem` horizontal padding and `0.75rem` vertical spacing.
- Contain real-time state icons (e.g., GPS Pulse, Cadence Indicator) with accompanying uppercase `label-sm` text.
- Active state: Emerald background at `0.15` opacity with solid `#10B981` text and borders.

### Cards & Metric Sheets
- Built from translucent slate (`rgba(30, 41, 59, 0.72)`) with a `1px` top-highlight border mimicking ambient sky illumination.
- Internal metrics are stacked: `label-sm` in `#94A3B8` on top, followed by prominent `metric-numeral` readouts in `#F8FAFC`, with inline unit designations in `#38BDF8`.

### Checkboxes & Radio Selectors
- Pill-segmented selectors for route preferences (e.g., "Well-Lit", "Paved Paths", "Fastest").
- Radio controls use concentric rings: 20px diameter, with a vibrant 10px `#10B981` center core when active.

### Input Fields (Location & Waypoint Search)
- Background: `#151E2A` with `border-radius: 9999px`.
- Prefix: Integrated luminescent magnifying glass or directional arrow (`#94A3B8`).
- Focus state: Subtle cyan perimeter illumination (`0 0 0 2px rgba(56, 189, 248, 0.4)`).

### Turn-by-Turn Instruction Banner
- Fixed to top safe area: Full-width floating pill with dual-density information.
- Dominant left-aligned navigation arrow in `#10B981`, street distance in `headline-sm`, and upcoming transition in `body-md` muted slate.