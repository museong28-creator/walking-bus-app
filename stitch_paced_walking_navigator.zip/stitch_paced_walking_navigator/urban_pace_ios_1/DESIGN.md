---
name: Urban Pace iOS
colors:
  surface: '#f7f9fb'
  surface-dim: '#d8dadc'
  surface-bright: '#f7f9fb'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#f2f4f6'
  surface-container: '#eceef0'
  surface-container-high: '#e6e8ea'
  surface-container-highest: '#e0e3e5'
  on-surface: '#191c1e'
  on-surface-variant: '#3c4a42'
  inverse-surface: '#2d3133'
  inverse-on-surface: '#eff1f3'
  outline: '#6c7a71'
  outline-variant: '#bbcabf'
  surface-tint: '#006c49'
  primary: '#006c49'
  on-primary: '#ffffff'
  primary-container: '#10b981'
  on-primary-container: '#00422b'
  inverse-primary: '#4edea3'
  secondary: '#565e74'
  on-secondary: '#ffffff'
  secondary-container: '#dae2fd'
  on-secondary-container: '#5c647a'
  tertiary: '#005ac2'
  on-tertiary: '#ffffff'
  tertiary-container: '#71a1ff'
  on-tertiary-container: '#00367a'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#6ffbbe'
  primary-fixed-dim: '#4edea3'
  on-primary-fixed: '#002113'
  on-primary-fixed-variant: '#005236'
  secondary-fixed: '#dae2fd'
  secondary-fixed-dim: '#bec6e0'
  on-secondary-fixed: '#131b2e'
  on-secondary-fixed-variant: '#3f465c'
  tertiary-fixed: '#d8e2ff'
  tertiary-fixed-dim: '#adc6ff'
  on-tertiary-fixed: '#001a42'
  on-tertiary-fixed-variant: '#004395'
  background: '#f7f9fb'
  on-background: '#191c1e'
  surface-variant: '#e0e3e5'
typography:
  headline-xl:
    fontFamily: Plus Jakarta Sans
    fontSize: 36px
    fontWeight: '700'
    lineHeight: 44px
    letterSpacing: -0.02em
  headline-xl-mobile:
    fontFamily: Plus Jakarta Sans
    fontSize: 28px
    fontWeight: '700'
    lineHeight: 36px
    letterSpacing: -0.02em
  headline-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 24px
    fontWeight: '600'
    lineHeight: 32px
    letterSpacing: -0.015em
  headline-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 20px
    fontWeight: '600'
    lineHeight: 28px
    letterSpacing: -0.01em
  body-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 16px
    fontWeight: '500'
    lineHeight: 24px
  body-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 20px
  body-sm:
    fontFamily: Plus Jakarta Sans
    fontSize: 12px
    fontWeight: '400'
    lineHeight: 16px
  label-numeric:
    fontFamily: JetBrains Mono
    fontSize: 15px
    fontWeight: '600'
    lineHeight: 20px
    letterSpacing: -0.03em
  label-badge:
    fontFamily: Plus Jakarta Sans
    fontSize: 11px
    fontWeight: '700'
    lineHeight: 14px
    letterSpacing: 0.04em
rounded:
  sm: 0.5rem
  DEFAULT: 1rem
  md: 1.5rem
  lg: 2rem
  xl: 3rem
  full: 9999px
spacing:
  gutter: 1rem
  margin: 1rem
  space-xs: 0.25rem
  space-sm: 0.5rem
  space-md: 0.75rem
  space-lg: 1rem
  space-xl: 1.5rem
---

## Brand & Style

This design system delivers a tactile, native-feeling urban mobility interface optimized specifically for mobile browsers within the iOS Safari environment. 

### Brand Personality & Philosophy
- **Dynamic Accuracy:** Focused on real-time walking pace, ETA precision, and adaptive physical movement rather than static vehicular tracking.
- **Calm Clarity:** Keeps the street map visually uncluttered while floating essential contextual data layers.
- **Native Polish:** Emulates iOS Human Interface Guidelines through translucent materials, responsive gestures, high legibility, and refined kinetic feedback.

### Visual Style
The aesthetic synthesizes **iOS Glassmorphism** with **Clean Modern Mobility UI**:
- **Layered Frosted Materials:** Extensive use of dynamic translucent backing panels (`backdrop-blur-md` and `backdrop-blur-lg`) to anchor the interface seamlessly over rich vector map canvases.
- **Spatial Separation:** Structural cards utilize deep radiuses, crisp border lines at micro-opacities, and subtle specular lighting cues.
- **Contextual Chroma:** Neutral foundation punctuated by functional chromatic signals that immediately communicate walking urgency and physical status.

## Colors

The palette balances map-friendly neutrals with semantic mobility colors, calibrated for readability in harsh sunlight and outdoor mobile conditions.

### Primary & Functional Roles
- **Primary (`#10B981` / `#059669`):** Represents optimal walking paths, steady paces, successful route matching, and the prime "Depart Now" status.
- **Secondary (`#0F172A` / `#1E293B`):** Deep slate tones for high-emphasis typography, primary bottom sheet headers, and floating primary navigation controls.
- **Tertiary (`#3B82F6`):** Precision GPS beacons, user trajectory arrows, and live friend-sharing telemetry.

### Status Palette
- **Pace Optimal / Relaxed:** `#10B981` (Emerald) — On-time arrival with natural stride.
- **Pace Urgent / Caution:** `#F59E0B` (Amber) — Requires brisk walking to catch upcoming transit links.
- **Pace Critical / Alert:** `#EF4444` (Rose) — Transit departure missed, signal degradation, or location permissions disabled.

### Surface & Translucency Tiers
- **Glass Overlay Canvas:** `rgba(255, 255, 255, 0.78)` paired with `backdrop-filter: blur(16px)` and a subtle interior stroke of `rgba(255, 255, 255, 0.4)`.
- **Sheet Background:** `#FFFFFF` with variable bottom padding honoring `env(safe-area-inset-bottom)`.
- **Underlay Map Veil:** `rgba(15, 23, 42, 0.08)` to separate vector basemaps from interactive UI chrome.

## Typography

The typography pairs the modern geometric precision and Apple-adjacent readability of **Plus Jakarta Sans** with tabular data-ready numerals via **JetBrains Mono**.

### Functional Application
- **Plus Jakarta Sans:** Drives all navigational labels, walking instructions, distance callouts, and bottom-sheet controls. Its open counters ensure immediate legibility while in motion outdoors.
- **JetBrains Mono:** Reserved for metrics subject to live updates—such as real-time countdown timers (e.g., `04:12`), speed meters (`4.8 km/h`), and stride frequency stats—preventing spatial jitter during variable shifts.
- **Mobile Readability Rules:** Never render primary distance labels below `14px`. Maintain tight negative tracking on display titles for native iOS character and clear visual weight.

## Layout & Spacing

The layout is built for direct one-handed ergonomics on mobile devices, accounting for WebKit viewports and browser navigation bars.

### Safe Areas & Dynamic Viewport Height
- Primary vertical layouts use `100dvh` (Dynamic Viewport Height) to prevent visual clipping caused by Safari's expanding and collapsing URL bar.
- Floating components and drawers must include padding referencing `env(safe-area-inset-top)` and `env(safe-area-inset-bottom)`.

### Grid & Composition
- **Bottom Drawer Paradigm:** The lower 45% to 85% of the viewport is reserved for interactive cards, sheets, and route data panels.
- **Floating HUD Zones:** Top-left, top-right, and mid-right quadrants host isolated, thumb-accessible floating action clusters.
- **Layout Distance Structure:** Standard side margin defaults to `1rem` (16px) to maximize map visibility while preserving comfortable touch target boundaries.

## Elevation & Depth

Visual hierarchy uses frosted glass physical layering rather than heavy drop shadows, mimicking native iOS control centers and spatial navigation maps.

### Elevation Levels

1. **Map Surface (Base 0):** The bottom-most interactive layer hosting Mapbox/MapLibre vector tiles.
2. **Ambient HUD Level (Floating FABs, Compass, Recenter Button):**
   - Translucent background: `rgba(255, 255, 255, 0.85)`
   - Filter: `backdrop-filter: blur(12px)`
   - Shadow: `0 4px 16px -2px rgba(15, 23, 42, 0.08), 0 2px 6px -1px rgba(15, 23, 42, 0.04)`
   - Border: `1px solid rgba(255, 255, 255, 0.6)`
3. **Interactive Bottom Sheet (Drawer Level):**
   - Background: Pure solid `#FFFFFF` in high-density areas, transitioning to translucent `rgba(255, 255, 255, 0.92)` with `backdrop-filter: blur(20px)` on collapsed previews.
   - Shadow: `0 -8px 30px rgba(15, 23, 42, 0.12)`
   - Top Edge Border: `1px solid rgba(15, 23, 42, 0.04)`
4. **Modals & Status Banners (Alert Tier):**
   - Elevated float with high-contrast, directional rim lighting.
   - Shadow: `0 12px 36px -4px rgba(15, 23, 42, 0.2)`

## Shapes

The design system adopts organic, smooth curvature mirroring iOS continuous corners (squircle-like appearance), maximizing touch-friendly appeal and urban polish.

### Shape Geometry Rules
- **Interactive Floating Action Buttons:** Circular (`rounded-full`) to differentiate tool controls from information cards.
- **Bottom Drawers & Modals:** `rounded-t-[32px]` for the primary bottom sheet; internal modular metric tiles use `rounded-2xl` (16px) or `rounded-3xl` (24px).
- **Grab Handles:** `w-9 h-1 rounded-full bg-slate-300` seated cleanly at the top of sliding drawers.
- **Badges & Micro-pills:** Fully rounded pill outlines (`rounded-full`) for status tags, walking rates, and live GPS accuracy meters.

## Components

### 1. Floating Map Action Buttons (FAB)
- **Geometry:** 48x48px circle, minimum touch target 48px.
- **Styling:** Glassmorphic white surface (`rgba(255, 255, 255, 0.9)`), centered SVG icon (`20px`), wrapped in a subtle hairline border (`rgba(255, 255, 255, 0.8)`).
- **Active State:** Scale down to `0.94` with standard iOS spring transition (`cubic-bezier(0.32, 0.72, 0, 1)`).

### 2. Live Pace & Speed Gauge
- **Structure:** Dual metric layout displaying target walk velocity versus measured stride velocity.
- **Visuals:** Circular progress ring or linear segmented pill utilizing Primary Green (`#10B981`) for on-track cadence, transitioning dynamically to Amber (`#F59E0B`) if the user falls below threshold to reach transit.
- **Numerical Value:** Formatted with `label-numeric` (e.g., `5.2 km/h`) paired with a dynamic micro-label (`+0.4 km/h to catch bus`).

### 3. Bottom Navigation Sheet (Collapsible Drawer)
- **Detent Snap Points:** 
  - *Collapsed (Peeking):* 96px — Shows next departure, remaining distance, and color-coded pace status.
  - *Half-Expanded:* 360px — Shows step-by-step turn guidance, elevation profile, and transfer buffers.
  - *Full View:* 85dvh — Detailed turn-by-turn route and companion sharing options.
- **Interior Layout:** Segmented navigation controls, primary departure action button, and companion friend tracker cards.

### 4. Beta & Status Badges
- **Pace Status Badge:** Pill shape with an 8px pulsing status dot.
  - *Relaxed:* Surface `#ECFDF5`, text `#065F46`, dot `#10B981`.
  - *Hurry:* Surface `#FEF3C7`, text `#92400E`, dot `#F59E0B`.
  - *Late Risk:* Surface `#FEE2E2`, text `#991B1B`, dot `#EF4444`.
- **System Beta Badge:** Compact pill featuring uppercase text (`label-badge`), slate-tinted background (`rgba(15, 23, 42, 0.06)`), and slate-900 border.

### 5. Primary Action Buttons (Depart / Route)
- **Height:** 54px full-width ergonomic touch strip.
- **Styling:** High-contrast `#10B981` fill with white semibold typography, or Deep Slate `#0F172A` with vibrant emerald accents.
- **Interaction:** Haptic feedback trigger on touch down, smooth scale compression (`0.98`).

### 6. Search & Destination Input
- **Structure:** Floating frosted pill at the top of the viewport.
- **Styling:** Inset shadow, slate-400 placeholder, leading search glyph, and trailing clear/voice input icons with instantaneous iOS keyboard avoidance.